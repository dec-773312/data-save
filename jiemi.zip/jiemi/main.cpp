#include <iostream>
#include <fstream>

int main()
{
    std::string key;
    std::string path_pt = "//Users/shuumichi/Desktop/MINIST-master/jiami";
    std::string path_save_jiemi = "/Users/shuumichi/Desktop/MINIST-master/jiemi";
    std::string str_len = "10";

    std::cin >>  key;
    std::filebuf in;
    std::filebuf outbuf;

    if (!in.open(path_pt, std::ios::in)) {
        std::cout << "fail to open file" << std::endl;
        return 1;
    }

    outbuf.open(path_save_jiemi, std::ios::out);

    FILE *in_file;
    in_file=fopen(path_pt.c_str(),"rb");//以读的方式打开二进制文件
    char ch=fgetc(in_file);


    int x = key.size();

    int i = 0;
    do {
        char ch = in.sgetc();
        ch = ch^key[i>=x?i=0:i++];

        outbuf.sputc(ch);
        //        std::cout << (int)ch<<std::endl;
    } while ( in.snextc() != EOF );
    outbuf.sputc(in.sgetc());
    outbuf.close();

    std::cout<<"\nsuccess create encryption model!" << std::endl;
    return 0;

}
